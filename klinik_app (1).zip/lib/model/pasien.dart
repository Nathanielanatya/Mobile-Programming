class Pasien {
  String? id;
  String namaPasien;
  Pasien({this.id, required this.namaPasien});
  get idPasien => 'id';
  get nomor_rm => 'nomor rm';
  get tanggal_lahir => 'tanggal lahir';
  get nomor_telepon => 'nomor telepon';
  get alamat => 'alamat';
}
