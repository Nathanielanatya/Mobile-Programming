class Pegawai {
  String? id;
  String namaPegawai;
  Pegawai({this.id, required this.namaPegawai});
  get idPegawai => 'id';
  get nip => 'nip';
  get tanggal_lahir => 'tanggal lahir';
  get nomor_telepon => 'nomor telepon';
  get email => 'email';
  get password => 'password';
}
